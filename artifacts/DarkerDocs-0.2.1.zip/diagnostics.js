const results=document.querySelector('#results');
const entries=new Map();
chrome.runtime.onMessage.addListener((message,sender)=>{
 if(message?.type!=='darkerdocs:diagnostics:result'||!/^https:\/\/docs\.google\.com\/(document|spreadsheets|presentation|forms)\//.test(sender.url||''))return;
 entries.set(sender.tab?.id, message.data);results.replaceChildren();for(const data of entries.values()){for(const [i,item] of [{app:data.app,theme:data.theme,renderer:data.renderer,overlays:data.overlays,colors:data.colors},...data.surfaces].entries()){const heading=document.createElement('h2');heading.textContent=data.app+' measurement '+i;const pre=document.createElement('pre');pre.textContent=JSON.stringify(item,null,2);results.append(heading,pre);}}
});
async function refresh(){entries.clear();results.textContent='Waiting for supported Workspace pages…';await chrome.storage.local.set({'darkerdocs.diagnostics.request':Date.now()});}
document.querySelector('#refresh').onclick=refresh;refresh();
