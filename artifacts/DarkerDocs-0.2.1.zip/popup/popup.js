(() => {
  "use strict";
  const { THEMES, LABELS, KEY, normalize } = DarkerDocs;
  const slider = document.querySelector("#theme");
  const status = document.querySelector("#status");
  const buttons = [...document.querySelectorAll("[data-theme]")];
  let queue = Promise.resolve();
  let revision = 0;
  function selection(theme) {
    const index = THEMES.indexOf(theme);
    slider.value = index;
    slider.setAttribute("aria-valuetext", LABELS[index]);
    document.querySelector("#selection").value = LABELS[index];
    buttons.forEach(button => button.setAttribute("aria-pressed", String(button.dataset.theme === theme)));
  }
  function render(theme){selection(theme);document.documentElement.dataset.ddTheme=theme;}
  function choose(theme) {
    document.documentElement.setAttribute('data-dd-ready','');
    selection(theme);
    // Property transitions can stagger ink independently of its background and
    // smoothly retarget from the current color during rapid input.
    document.documentElement.dataset.ddTheme=theme;
    status.textContent = "Saving…";
    const current = ++revision;
    // Serialize writes so rapid dragging cannot persist an older selection last.
    queue = queue.catch(() => {}).then(() => chrome.storage.local.set({ [KEY]: { theme } })).then(() => {
      if (current === revision) status.textContent = "Saved · Applied across Workspace";
    }).catch(() => {
      if (current === revision) status.textContent = "Couldn’t save. Choose your theme to retry.";
    });
  }
  slider.addEventListener("input", () => choose(THEMES[Number(slider.value)]));
  buttons.forEach(button => button.addEventListener("click", () => choose(button.dataset.theme)));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[KEY] && !status.textContent.startsWith("Saving")) render(normalize(changes[KEY].newValue).theme);
  });
  chrome.storage.local.get(KEY).then(values => {
    render(normalize(values[KEY]).theme);
    status.textContent = "";
    slider.disabled = false;
    buttons.forEach(button => { button.disabled = false; });
  }).catch(() => {
    status.textContent = "Couldn’t load your preference. Reopen to retry.";
  });
})();
