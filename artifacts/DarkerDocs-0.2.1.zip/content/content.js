(() => {
  'use strict';
  const {KEY,THEMES,normalize,route,parseColor,mapColor,outputView}=DarkerDocs;
  const ATTRS=['data-dd-c','data-dd-b','data-dd-m','data-dd-ot','data-dd-or','data-dd-ob','data-dd-ol','data-dd-f','data-dd-s','data-dd-t','data-dd-original'];
  const MEDIA='img,picture,video,iframe,canvas,darkerdocs-surface,defs,clipPath,mask,filter,linearGradient,radialGradient,pattern,[data-dd-preserve],.docs-icon-img,.goog-palette,.goog-palette-cell,.docs-colormenu,.docs-colorpalette,[data-color]';
  const marked=new Set(),pending=new Set(),registry=new Map();
  let settings={theme:'default'},activeRoute=null,frame=0,version=0,loaded=false,transition,styleNode,notice;
  let dirtyRules=false,ruleText='';
  let motionStyle,finishMotion;
  function stopTransition(){transition?.skipTransition();transition=null;finishMotion?.();finishMotion=null;}
  function motionLayers(){
    const html=document.documentElement,targets=[];
    if(!motionStyle?.isConnected){
      motionStyle=document.createElement('style');motionStyle.id='darkerdocs-motion';
      let css='';
      for(const [stage,limit,duration,delay] of [['text',12,760,120],['control',16,740,240]])for(let i=0;i<limit;i++){
        const name=`dd-${stage}-${i}`;
        css+=`[data-dd-motion="${name}"]{view-transition-name:${name}!important}html[data-dd-animating]::view-transition-group(${name}){--dd-motion-duration:${duration}ms;--dd-motion-delay:${delay}ms}`;
      }
      motionStyle.textContent=css;(document.head||html).append(motionStyle);
    }
    // Bound the number of extra snapshots. Canvas content stays in the root
    // crossfade so authored drawing commands and image pixels remain untouched.
    for(const [stage,selector,limit] of [
      ['control','button,[role="button"],input,select,textarea,[role="tab"]',16],
      ['text','h1,h2,h3,[role="heading"],.docs-titlebar,.docs-title-input-label',12]
    ]){
      let count=0;
      for(const e of document.querySelectorAll(selector)){
        if(count===limit)break;
        if(e.closest(MEDIA+',svg,[data-dd-original]')||e.closest('[data-dd-motion]')||e.querySelector('[data-dd-motion]')||!e.getClientRects().length)continue;
        const s=getComputedStyle(e);
        if(s.visibility!=='visible'||s.viewTransitionName!=='none')continue;
        e.setAttribute('data-dd-motion',`dd-${stage}-${count++}`);targets.push(e);
      }
    }
    html.setAttribute('data-dd-animating','');
    finishMotion=()=>{html.removeAttribute('data-dd-animating');targets.forEach(e=>e.removeAttribute('data-dd-motion'));};
    return finishMotion;
  }
  function token(value,kind,original=false){
    const key=kind+'|'+original+'|'+value;
    if(registry.has(key))return registry.get(key);
    const id='c'+registry.size;registry.set(key,id);
    const prop={c:'color',b:'background-color',m:'background-color',ot:'border-top-color',or:'border-right-color',ob:'border-bottom-color',ol:'border-left-color',f:'fill',s:'stroke',t:'-webkit-text-fill-color'}[kind];
    for(const theme of THEMES.filter(t=>t!=='default'))ruleText+=`html[data-dd-theme="${theme}"]:not([data-dd-measuring]) [data-dd-${kind}="${id}"]{${prop}:${original?value:mapColor(value,theme,kind==='b'?'ui-bg':kind.startsWith('o')?'ui-border':'ui-ink')}!important}\n`;
    dirtyRules=true;return id;
  }
  function clear(e){for(const attr of ATTRS)e.removeAttribute(attr);marked.delete(e);}
  function isOriginalSvg(e){return activeRoute?.app==='slides'&&e.localName==='svg'&&!e.closest('#docs-chrome,[role="button"],button,[role="toolbar"],.docs-companion-app-switcher-container');}
  function mark(e,kind,value,original=false){e.setAttribute('data-dd-'+kind,token(value,kind,original));marked.add(e);}
  function decorate(e){
    if(e.matches(MEDIA)||e.closest('darkerdocs-surface,.goog-palette,.docs-colormenu'))return;
    clear(e);
    const s=getComputedStyle(e),fg=parseColor(s.color),bg=parseColor(s.backgroundColor),fill=parseColor(s.webkitTextFillColor);
    if(bg&&bg.alpha>.01)mark(e,s.maskImage!=='none'?'m':'b',s.backgroundColor);
    // Google overlays a transparent title input over a visible label. Keep its
    // native transparency rather than painting a second, offset title.
    if(fg&&fg.alpha>0&&(!fill||fill.alpha>0))mark(e,'c',s.color);
    if(e.matches('input,textarea')&&fill&&fill.alpha>0)mark(e,'t',s.webkitTextFillColor);
    // Transparent sides form Google's CSS arrows; never color all four sides
    // from just the top edge or those arrows become solid rectangles.
    for(const [kind,side] of [['ot','Top'],['or','Right'],['ob','Bottom'],['ol','Left']])if(parseColor(s['border'+side+'Color'])?.alpha>0&&s['border'+side+'Style']!=='none')mark(e,kind,s['border'+side+'Color']);
    if(e instanceof SVGElement){
      if(parseColor(s.fill)?.alpha>0)mark(e,'f',s.fill);
      if(parseColor(s.stroke)?.alpha>0)mark(e,'s',s.stroke);
    }
    if(isOriginalSvg(e)){
      for(const [kind,value] of [['c',s.color],['f',s.fill],['s',s.stroke]])if(parseColor(value))mark(e,kind,value,true);
      e.setAttribute('data-dd-original','');
    }
  }
  function scan(root){
    if(!(root instanceof Element)||root.matches(MEDIA)||root.closest('darkerdocs-surface,.goog-palette,.docs-colormenu'))return;
    decorate(root);if(isOriginalSvg(root))return;
    const walker=document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT,{acceptNode(node){return node.matches(MEDIA)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT;}});
    while(walker.nextNode()){
      const e=walker.currentNode;
      if(e.closest('[data-dd-original]'))continue;
      decorate(e);
    }
  }
  function updateNotice(){
    const preserved=Boolean(document.documentElement?.dataset.ddPreserved);
    const needed=(Boolean(document.documentElement?.dataset.ddNeedsReload)||preserved)&&settings.theme!=='default'&&Boolean(document.documentElement?.dataset.ddTheme)&&!outputView(document);
    if(!needed){notice?.remove();notice=null;return;}
    if(!document.body)return;
    if(!notice?.isConnected){notice=document.createElement('aside');notice.id='darkerdocs-notice';notice.setAttribute('data-dd-preserve','');notice.setAttribute('role','status');document.body.append(notice);}
    const message=preserved?'Some content keeps its original appearance to preserve its colors.':'Reload this tab to finish updating the canvas theme.';
    if(notice.textContent!==message)notice.textContent=message;
  }
  function flush(){
    frame=0;activeRoute=route(location.href);
    const html=document.documentElement;if(!html||!activeRoute){pending.clear();return;}
    if(outputView(document)){stopTransition();nativeMode();document.dispatchEvent(new Event('darkerdocs:theme'));pending.clear();return;}
    if(settings.theme==='default'){pending.clear();return;}
    html.dataset.ddApp=activeRoute.app;html.dataset.ddView=activeRoute.view;
    if(!styleNode?.isConnected){styleNode=document.createElement('style');styleNode.id='darkerdocs-colors';(document.head||html).append(styleNode);dirtyRules=true;}
    const roots=[...pending].filter(e=>e?.isConnected);pending.clear();
    html.setAttribute('data-dd-measuring','');
    try{
      marked.forEach(e=>{if(!e.isConnected)marked.delete(e);});
      roots.filter(e=>!roots.some(other=>other!==e&&other.contains(e))).forEach(scan);
      if(dirtyRules){styleNode.textContent='@media screen{'+ruleText+'}';dirtyRules=false;}
    }finally{html.removeAttribute('data-dd-measuring');}
    updateNotice();
  }
  function schedule(node){if(node instanceof Element&&!node.closest('darkerdocs-surface,#darkerdocs-colors,#darkerdocs-motion'))pending.add(node);if(!frame)frame=requestAnimationFrame(flush);}
  function nativeMode(){const html=document.documentElement;if(!html)return;delete html.dataset.ddTheme;delete html.dataset.ddApp;delete html.dataset.ddView;marked.forEach(clear);notice?.remove();notice=null;}
  function setTheme(value,animate=true){
    const changed=settings.theme!==normalize(value).theme;
    stopTransition();
    settings=normalize(value);const html=document.documentElement;if(!html){schedule(document.documentElement);return;}
    activeRoute=route(location.href);
    const commit=()=>{
      if(settings.theme==='default'||!activeRoute||outputView(document)){nativeMode();document.dispatchEvent(new Event('darkerdocs:theme'));return;}
      html.dataset.ddTheme=settings.theme;html.dataset.ddApp=activeRoute.app;html.dataset.ddView=activeRoute.view;
      pending.add(html);flush();
      document.dispatchEvent(new Event('darkerdocs:theme'));
    };
    const motion=!matchMedia('(prefers-reduced-motion: reduce)').matches;
    if(loaded&&changed&&animate&&motion&&activeRoute&&!outputView(document)&&document.startViewTransition){
      const cleanup=motionLayers();
      transition=document.startViewTransition(commit);
      const current=transition;
      current.finished.catch(()=>{}).then(()=>{if(transition===current){cleanup();transition=null;finishMotion=null;}});
    }else commit();
    loaded=true;
  }
  const observer=new MutationObserver(records=>{
    if(records.every(r=>r.target===styleNode||r.target?.closest?.('darkerdocs-surface,#darkerdocs-colors,#darkerdocs-motion')||(r.type==='childList'&&[...r.addedNodes,...r.removedNodes].every(n=>n===motionStyle))))return;
    for(const r of records){
      if(r.type==='childList'){r.addedNodes.forEach(schedule);if(r.removedNodes.length)schedule(r.target);}
      else if(['data-dd-needs-reload','data-dd-preserved'].includes(r.attributeName))updateNotice();
      else schedule(r.target);
    }
    if(!document.documentElement?.dataset.ddApp&&settings.theme!=='default'&&document.documentElement&&!outputView(document))setTheme(settings,false);
  });
  observer.observe(document,{subtree:true,childList:true,attributes:true,attributeFilter:['class','style','aria-selected','aria-disabled','data-dd-needs-reload','data-dd-preserved']});
  chrome.storage.onChanged.addListener((changes,area)=>{if(area!=='local')return;if(changes[KEY]){version++;setTheme(changes[KEY].newValue);}if(changes['darkerdocs.diagnostics.request'])chrome.runtime.sendMessage({type:'darkerdocs:diagnostics:result',data:diagnostics()}).catch(()=>{});});
  const initial=version;chrome.storage.local.get(KEY).then(values=>{if(version===initial)setTheme(values[KEY],false);}).catch(()=>setTheme({theme:'default'},false));
  for(const event of ['popstate','hashchange'])addEventListener(event,()=>{stopTransition();if(!route(location.href))nativeMode();else setTheme(settings,false);});
  addEventListener('beforeprint',stopTransition);
  matchMedia('print').addEventListener('change',event=>{if(event.matches)stopTransition();});
  matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change',event=>{if(event.matches)stopTransition();});
  // Read-only diagnostics: no document text, document model or authored data is returned.
  function diagnostics(){
    const selectors=['.docs-title-input','.docs-title-input-label','.waffle-printing-pane','[aria-label="Insertion"]'];
    return {app:activeRoute?.app,theme:settings.theme,renderer:document.documentElement.dataset.ddRenderer||null,overlays:document.querySelectorAll('darkerdocs-surface').length,colors:registry.size,
      surfaces:selectors.flatMap(selector=>[...document.querySelectorAll(selector)].slice(0,12).map(e=>{const s=getComputedStyle(e);return {selector,tag:e.tagName,classes:e.getAttribute('class'),color:s.color,fill:s.fill,background:s.backgroundColor,image:s.backgroundImage!=='none',mask:s.maskImage!=='none',opacity:s.opacity,width:s.width,height:s.height,parents:[e.parentElement?.className]};}))};
  }
  chrome.runtime?.onMessage?.addListener((message,sender,sendResponse)=>{if(message?.type==='darkerdocs:diagnostics')sendResponse(diagnostics());});
})();
