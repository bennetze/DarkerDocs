/* MAIN-world adapter. Native canvas pixels and serialization stay original.
   The themed screen copy lives in a pointer-transparent closed shadow root. */
(() => {
  'use strict';
  const {route,mapColor,outputView}=globalThis.DarkerDocs;
  if(!['docs','sheets'].includes(route(location.href)?.app)||!globalThis.CanvasRenderingContext2D)return;
  const proto=CanvasRenderingContext2D.prototype,cp=HTMLCanvasElement.prototype;
  const getContext=cp.getContext,descriptors=Object.getOwnPropertyDescriptors(proto),native={};
  for(const [name,d] of Object.entries(descriptors))if(typeof d.value==='function')native[name]=d.value;
  const contexts=new WeakMap(),canvases=new WeakMap(),active=new Set(),mirrors=new WeakSet(),hosts=new WeakMap(),imageCache=new WeakMap(),watchedImages=new WeakSet();
  const commands=new Set('save restore beginPath closePath moveTo lineTo bezierCurveTo quadraticCurveTo arc arcTo ellipse rect roundRect clip fill stroke clearRect fillRect strokeRect fillText strokeText drawImage putImageData setTransform resetTransform transform scale rotate translate setLineDash drawFocusIfNeeded reset'.split(' '));
  const colors=new Set(['fillStyle','strokeStyle','shadowColor']);
  let theme='default',replaying=false,queued=false,replayDepth=0,lastSnapshot=null;
  const MAX_OPS=60000,MAX_BYTES=12*1024*1024;
  function each(fn){for(const ref of active){const r=ref.deref();if(r)fn(r);else active.delete(ref);}}
  function paintValue(name,value){return name==='shadowColor'?value:mapColor(value,theme,'paint');}
  function seed(r){for(const name of colors){const d=descriptors[name];if(d?.get&&d?.set)d.set.call(r.mc,paintValue(name,d.get.call(r.ctx)));}}
  function reset(r){r.width=r.canvas.width;r.height=r.canvas.height;r.ops=[];r.bytes=0;r.overflow=false;r.preserved=false;r.clipped=false;r.clipStack=[];r.revision=(r.revision||0)+1;r.assets=new WeakSet();r.snapshot=null;r.canvas.removeAttribute('data-dd-canvas-fallback');if(r.mirror){r.mirror.width=r.width;r.mirror.height=r.height;seed(r);}}
  function record(ctx){if(mirrors.has(ctx.canvas))return null;let r=contexts.get(ctx);if(!r){r={ctx,canvas:ctx.canvas,width:ctx.canvas.width,height:ctx.canvas.height,ops:[],bytes:0,overflow:false,mirror:null,host:null,painted:0};contexts.set(ctx,r);canvases.set(ctx.canvas,r);active.add(new WeakRef(r));}if(r.width!==r.canvas.width||r.height!==r.canvas.height)reset(r);return r;}
  function fallback(r,preserved=false){r.overflow=true;r.preserved=preserved;r.ops=[];r.snapshot=null;r.assets=new WeakSet();r.bytes=0;r.host?.remove();r.host=null;r.mirror=null;r.mc=null;r.canvas.removeAttribute('data-dd-source-canvas');r.canvas.setAttribute('data-dd-canvas-fallback','');status();}
  function remember(r,op){if(r.overflow)return;if(r.ops.length>=MAX_OPS||r.bytes>MAX_BYTES){fallback(r);return;}r.ops.push(op);r.revision=(r.revision||0)+1;}
  const pixelCalls=new Set('fill stroke fillRect strokeRect fillText strokeText drawImage putImageData clearRect'.split(' '));
  function pruneCoveredPixels(r,name,args){
    if(r.overflow||r.clipped||!['clearRect','fillRect'].includes(name))return;
    const [x,y,w,h]=args,t=r.ctx.getTransform();
    if(x>0||y>0||x+w<r.width||y+h<r.height||t.a!==1||t.b!==0||t.c!==0||t.d!==1||t.e!==0||t.f!==0)return;
    if(name==='fillRect'&&(r.ctx.globalAlpha!==1||r.ctx.globalCompositeOperation!=='source-over'||r.ctx.filter!=='none'||DarkerDocs.parseColor(r.ctx.fillStyle)?.alpha!==1))return;
    // A complete, unclipped repaint covers previous pixels. Keep paths and
    // drawing state, but release obsolete raster snapshots and paint calls.
    r.ops=r.ops.filter(op=>op.kind!=='call'||!pixelCalls.has(op.name));r.bytes=0;r.assets=new WeakSet();
  }
  function displaySource(source){const r=canvases.get(source);return theme!=='default'&&!r?.overflow&&r?.mirror||source;}
  function copyImage(source){
    const recorded=canvases.get(source);
    if(recorded&&!recorded.overflow&&recorded.ops.length){
      if(!recorded.snapshot||recorded.snapshot.revision!==recorded.revision)recorded.snapshot={width:source.width,height:source.height,ops:recorded.ops.slice(),revision:recorded.revision};
      // Recorded tiles retain drawing commands, not a full pixel buffer. A
      // retina-sized scratch canvas must not consume its logical bitmap size
      // in the history budget for every small cropped draw.
      return {snapshot:recorded.snapshot,bytes:recorded.snapshot.ops.length*48};
    }
    if(!source||!(source instanceof HTMLCanvasElement||source instanceof HTMLVideoElement||source instanceof HTMLImageElement||(globalThis.ImageBitmap&&source instanceof ImageBitmap)))return {display:source,bytes:0};
    if(source instanceof HTMLImageElement){
      const cached=imageCache.get(source);if(cached&&cached.src===source.currentSrc)return cached.image;
      if(!watchedImages.has(source)){watchedImages.add(source);source.addEventListener('load',()=>imageCache.delete(source));}
    }
    const width=source.videoWidth||source.naturalWidth||source.width,height=source.videoHeight||source.naturalHeight||source.height;
    if(!width||!height||width*height*4>MAX_BYTES)return {display:displaySource(source),bytes:MAX_BYTES+1};
    const c=document.createElement('canvas');mirrors.add(c);c.width=width;c.height=height;
    native.drawImage.call(getContext.call(c,'2d'),displaySource(source),0,0);
    const image={display:c,bytes:width*height*4};
    if(source instanceof HTMLImageElement)imageCache.set(source,{src:source.currentSrc,image});
    return image;
  }
  function snapshotSurface(snapshot){
    if(lastSnapshot?.source===snapshot)return lastSnapshot.canvas;
    const canvas=document.createElement('canvas');mirrors.add(canvas);canvas.width=snapshot.width;canvas.height=snapshot.height;
    const r={canvas,ctx:getContext.call(canvas,'2d'),width:snapshot.width,height:snapshot.height,ops:snapshot.ops,mirror:null,host:null};
    repaint(r);lastSnapshot={source:snapshot,canvas:r.mirror};return r.mirror;
  }
  function execute(r,name,args){
    const m=r.mc;
    if(['fill','stroke','fillRect','strokeRect','fillText','strokeText'].includes(name)){
      const property=name.startsWith('stroke')?'strokeStyle':'fillStyle',paint=r.ink?.[property]??descriptors[property].get.call(r.ctx);
      if(globalThis.CanvasGradient&&paint instanceof CanvasGradient)throw Object.assign(new Error('Preserve gradient surface'),{ddPreserve:true});
    }
    if(name==='drawImage')args=[args[0]?.ddImage?(args[0].snapshot?snapshotSurface(args[0].snapshot):args[0].display):displaySource(args[0]),...args.slice(1)];
    if(name==='fillText'||name==='strokeText'||name==='fill'){
      const property=name==='strokeText'?'strokeStyle':'fillStyle',d=descriptors[property],previous=d.get.call(m);
      d.set.call(m,mapColor(r.ink?.[property]??d.get.call(r.ctx),theme,'ink'));
      try{native[name].apply(m,args);}finally{d.set.call(m,previous);}
    }else{native[name]?.apply(m,args);if(name==='reset')seed(r);}
  }
  function makeMirror(r){if(r.mirror)return;r.mirror=document.createElement('canvas');mirrors.add(r.mirror);r.mirror.width=r.width;r.mirror.height=r.height;r.mc=getContext.call(r.mirror,'2d');seed(r);}
  function mount(r){
    if(theme==='default'||!r.canvas.isConnected||!r.mirror)return;
    if(!r.host){r.host=document.createElement('darkerdocs-surface');hosts.set(r.host,new WeakRef(r.canvas));r.host.setAttribute('aria-hidden','true');r.host.attachShadow({mode:'closed'}).append(r.mirror);r.mirror.style.cssText='display:block;width:100%;height:100%;pointer-events:none';}
    r.canvas.removeAttribute('data-dd-source-canvas');
    const s=getComputedStyle(r.canvas),left=r.canvas.offsetLeft,top=r.canvas.offsetTop;
    r.host.style.cssText=`position:absolute;left:${left}px;top:${top}px;width:${s.width};height:${s.height};transform:${s.transform};transform-origin:${s.transformOrigin};z-index:${s.zIndex};opacity:${s.opacity};pointer-events:none;display:${s.display==='none'?'none':'block'};margin:0;padding:0;border:0;`;
    if(r.host.parentNode!==r.canvas.parentNode)r.canvas.after(r.host);
    r.canvas.setAttribute('data-dd-source-canvas','');
  }
  function repaint(r){
    if(theme==='default'){r.host?.remove();r.host=null;r.canvas.removeAttribute('data-dd-source-canvas');return;}
    if(r.overflow)return;
    makeMirror(r);r.mirror.width=r.canvas.width;r.mirror.height=r.canvas.height;
    r.ink={fillStyle:'#000000',strokeStyle:'#000000'};const stack=[];
    descriptors.fillStyle.set.call(r.mc,mapColor('#000000',theme,'paint'));descriptors.strokeStyle.set.call(r.mc,mapColor('#000000',theme,'paint'));
    replaying=true;replayDepth++;
    try{for(const op of r.ops){if(op.kind==='set'){if(colors.has(op.name))r.ink[op.name]=op.value;descriptors[op.name].set.call(r.mc,colors.has(op.name)?paintValue(op.name,op.value):op.value);}else{if(op.name==='save')stack.push({...r.ink});if(op.name==='restore'&&stack.length)r.ink=stack.pop();execute(r,op.name,op.args);}}}
    finally{replayDepth--;replaying=replayDepth>0;if(!replayDepth)lastSnapshot=null;r.ink=null;}
    mount(r);
  }
  cp.getContext=function(type,...args){const ctx=getContext.call(this,type,...args);if(type==='2d'&&ctx&&!mirrors.has(this))record(ctx);return ctx;};
  for(const [name,d] of Object.entries(descriptors)){
    if(d.set&&d.get)Object.defineProperty(proto,name,{...d,set(value){d.set.call(this,value);const r=record(this);if(!r||replaying)return;const actual=d.get.call(this);remember(r,{kind:'set',name,value:actual});if(r.mc)d.set.call(r.mc,colors.has(name)?paintValue(name,actual):actual);}});
    else if(commands.has(name)&&native[name])Object.defineProperty(proto,name,{...d,value:function(...args){
      const r=record(this);let image;
      if(r&&name==='drawImage'&&!r.overflow){try{image=copyImage(args[0]);}catch{/* Native call below retains native validation/errors. */}}
      const result=native[name].apply(this,args);if(!r||replaying)return result;
      if(name==='reset')reset(r);
      if(name==='save')(r.clipStack??=[]).push(Boolean(r.clipped));
      if(name==='restore'&&r.clipStack?.length)r.clipped=r.clipStack.pop();
      if(name==='clip')r.clipped=true;
      pruneCoveredPixels(r,name,args);
      const stored=args.map(v=>globalThis.Path2D&&v instanceof Path2D?new Path2D(v):v);
      if(image){const asset=image.snapshot||image.display;r.assets??=new WeakSet();if(asset&&typeof asset==='object'&&!r.assets.has(asset)){r.assets.add(asset);r.bytes+=image.bytes;}stored[0]={...image,ddImage:true};}
      if(name==='putImageData'&&args[0]&&!r.overflow){stored[0]=new ImageData(new Uint8ClampedArray(args[0].data),args[0].width,args[0].height);r.bytes+=stored[0].data.byteLength;}
      remember(r,{kind:'call',name,args:stored});r.painted++;
      if(theme!=='default'&&!r.overflow){try{if(!r.mirror)repaint(r);else{execute(r,name,args);if(!r.host&&r.canvas.isConnected)mount(r);}}catch(error){fallback(r,Boolean(error.ddPreserve));}}
      return result;
    }});
  }
  for(const name of ['width','height']){const d=Object.getOwnPropertyDescriptor(cp,name);Object.defineProperty(cp,name,{...d,set(value){d.set.call(this,value);if(mirrors.has(this))return;const r=canvases.get(this);if(r)reset(r);}});}
  for(const name of ['setAttribute','removeAttribute']){const original=cp[name];cp[name]=function(...args){const result=original.apply(this,args);if(['width','height'].includes(String(args[0]).toLowerCase())){const r=canvases.get(this);if(r)reset(r);}return result;};}
  function status(){let surfaces=0,painted=0,overflow=0,preserved=0;each(r=>{if(r.canvas.isConnected){surfaces++;painted+=r.painted;if(r.overflow){overflow++;if(r.preserved)preserved++;}}});const html=document.documentElement;if(html){html.dataset.ddRenderer=JSON.stringify({surfaces,painted,overflow,preserved});if(overflow>preserved)html.dataset.ddNeedsReload='true';else delete html.dataset.ddNeedsReload;if(preserved)html.dataset.ddPreserved='true';else delete html.dataset.ddPreserved;}}
  function refresh(){const next=outputView(document)?'default':document.documentElement?.dataset.ddTheme||'default';if(next!==theme){theme=next;each(r=>{try{repaint(r);}catch(error){fallback(r,Boolean(error.ddPreserve));}});}each(r=>{if(r.canvas.isConnected&&!r.overflow)mount(r);else{r.host?.remove();r.host=null;}});document.querySelectorAll('darkerdocs-surface').forEach(host=>{if(!hosts.get(host)?.deref()?.isConnected)host.remove();});status();}
  const observer=new MutationObserver(records=>{if(records.every(r=>r.target.nodeName==='DARKERDOCS-SURFACE'||(r.type==='childList'&&[...r.addedNodes,...r.removedNodes].every(n=>n.nodeName==='DARKERDOCS-SURFACE'))))return;if(!queued){queued=true;requestAnimationFrame(()=>{queued=false;refresh();});}});
  observer.observe(document,{subtree:true,childList:true,attributes:true,attributeFilter:['data-dd-theme','style','class','width','height']});
  addEventListener('resize',()=>each(mount));
  document.addEventListener('darkerdocs:theme',refresh);
  addEventListener('beforeprint',()=>each(r=>{r.host?.remove();r.canvas.removeAttribute('data-dd-source-canvas');}));
  addEventListener('afterprint',()=>each(mount));
})();
