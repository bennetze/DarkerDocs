/* Shared by the isolated content script, popup and dependency-free tests. */
(() => {
  "use strict";
  const THEMES = Object.freeze(["oled", "dark", "default", "cream"]);
  const LABELS = Object.freeze(["OLED Black", "Dark Grey", "Default", "Cream"]);
  const KEY = "darkerdocs.settings.v1";
  const PALETTES = Object.freeze({
    oled:{bg:"#000000",surface:"#080808",raised:"#161616",text:"#e8eaed",muted:"#aeb4bd",paper:"#000000",accent:"#a8c7fa"},
    dark:{bg:"#101214",surface:"#17191c",raised:"#23262b",text:"#e4e7ec",muted:"#aab1bc",paper:"#191b1e",accent:"#a8c7fa"},
    default:{bg:"#ffffff",surface:"#f0f4f9",raised:"#ffffff",text:"#1f1f1f",muted:"#5f6368",paper:"#ffffff",accent:"#0b57d0"},
    cream:{bg:"#f5d5a1",surface:"#ffe2b3",raised:"#ffeacc",text:"#3f2a18",muted:"#715237",paper:"#ffe4b7",accent:"#174d94"}
  });
  function normalize(value) {
    return { theme: THEMES.includes(value?.theme) ? value.theme : "dark" };
  }
  function route(input) {
    let url;
    try { url = new URL(input); } catch { return null; }
    if (url.protocol !== "https:" || url.hostname !== "docs.google.com") return null;
    const match = url.pathname.match(/^\/(document|spreadsheets|presentation|forms)\//);
    if (!match) return null;
    const app = { document: "docs", spreadsheets: "sheets", presentation: "slides", forms: "forms" }[match[1]];
    if (/\/(?:print|export|present|embed|htmlpresent)(?:\/|$)/.test(url.pathname) || (app === "slides" && /\/(?:pub|pubembed)\/?$/.test(url.pathname)) || url.searchParams.get("output") === "pdf") return null;
    const file = /\/d\//.test(url.pathname);
    return { app, view: file ? (app === "forms" && /\/viewform\/?$/.test(url.pathname) ? "respondent" : "file") : "home" };
  }
  function parseColor(value) {
    if(typeof value!=="string")return null;
    if(value==="transparent")return {rgb:[0,0,0],alpha:0};
    const hex=value.match(/^#([\da-f]{3}|[\da-f]{4}|[\da-f]{6}|[\da-f]{8})$/i);
    if(hex){const h=hex[1].length<5?[...hex[1]].map(c=>c+c).join(""):hex[1];return {rgb:[0,2,4].map(i=>parseInt(h.slice(i,i+2),16)),alpha:h.length===8?parseInt(h.slice(6),16)/255:1};}
    const m = value.match(/^rgba?\(\s*([\d.]+)[, ]+([\d.]+)[, ]+([\d.]+)(?:\s*[,/]\s*([\d.]+))?\s*\)$/);
    const srgb = value.match(/^color\(srgb\s+([\d.e+-]+)\s+([\d.e+-]+)\s+([\d.e+-]+)(?:\s*\/\s*([\d.]+))?\s*\)$/);
    const parts = m || srgb;
    if (!parts) return null;
    return { rgb: parts.slice(1,4).map(channel => Math.max(0, Math.min(255, Number(channel) * (srgb ? 255 : 1)))), alpha: parts[4] === undefined ? 1 : Number(parts[4]) };
  }
  function hsl(rgb){const [r,g,b]=rgb.map(v=>v/255),max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min,l=(max+min)/2;let h=0,s=0;if(d){s=d/(1-Math.abs(2*l-1));h=(max===r?(g-b)/d+(g<b?6:0):max===g?(b-r)/d+2:(r-g)/d+4)/6;}return [h,s,l];}
  function rgbFromHsl(h,s,l){const a=s*Math.min(l,1-l);return [0,8,4].map(n=>{const k=(n+h*12)%12;return Math.round(255*(l-a*Math.max(-1,Math.min(k-3,9-k,1))));});}
  function luminance(rgb){return rgb.map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;}).reduce((v,c,i)=>v+c*[.2126,.7152,.0722][i],0);}
  function mapColor(value,theme,role="ink"){
    const color=parseColor(value),p=PALETTES[theme];if(!color||!p||theme==="default"||color.alpha===0)return value;
    const [h,s,l]=hsl(color.rgb),chroma=Math.max(...color.rgb)-Math.min(...color.rgb);
    // UI surfaces include Google's faintly tinted neutral tokens. Authored
    // ink/paint uses a stricter rule so pastel green, pink and blue stay colored.
    const mono=role==='ui-bg'||role==='ui-border'?chroma<=24:chroma<=3||s<=.08;let rgb;
    if(role==="ui-ink"&&mono)rgb=parseColor(l>.2&&l<.7?p.muted:p.text).rgb;
    else if(role==="ui-border"&&mono)rgb=parseColor(theme==="cream"?'#b5966a':theme==="oled"?'#383b40':'#444950').rgb;
    else if(role==="ui-bg"){if(mono)rgb=parseColor(l>.96?p.surface:l>.8?p.bg:p.raised).rgb;else rgb=rgbFromHsl(h,Math.min(s,.65),theme==="cream"?Math.min(.84,Math.max(.64,l)):.13+.2*(1-l));}
    else if(mono){const paper=parseColor(p.paper).rgb,ink=parseColor(p.text).rgb;rgb=paper.map((v,i)=>Math.round(v+(ink[i]-v)*(1-l)));}
    else if(theme==="cream")rgb=rgbFromHsl(h,s,role.endsWith('ink')?Math.min(l,.36):Math.min(.85,Math.max(.24,l)));
    else rgb=rgbFromHsl(h,s,role.endsWith('ink')?Math.max(.65,Math.min(.8,1-l)):.1+.72*(1-l));
    if(theme!=='cream'&&role==='paint'&&!mono){let light=hsl(rgb)[2];while(luminance(rgb)>.12&&light>.01){light*=.9;rgb=rgbFromHsl(h,s,light);}}
    return `rgba(${rgb.join(",")},${color.alpha})`;
  }
  function neutral(value) {
    const color = parseColor(value);
    if (!color || color.alpha < 0.95) return false;
    const rgb = color.rgb;
    // Used only for identified application controls, NEVER authored content.
    return Math.max(...rgb) - Math.min(...rgb) <= 24;
  }
  function outputView(root){return [...root.querySelectorAll('.waffle-printing-pane')].some(e=>e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden');}
  globalThis.DarkerDocs = Object.freeze({ THEMES, LABELS, KEY, PALETTES, normalize, route, neutral, parseColor, mapColor, outputView });
})();
